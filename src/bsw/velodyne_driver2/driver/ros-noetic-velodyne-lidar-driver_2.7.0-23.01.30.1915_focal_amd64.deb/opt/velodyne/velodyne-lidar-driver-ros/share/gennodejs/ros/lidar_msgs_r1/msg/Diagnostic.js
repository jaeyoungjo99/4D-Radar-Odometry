// Auto-generated. Do not edit!

// (in-package lidar_msgs_r1.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Diagnostic {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.state = null;
      this.modelNum = null;
      this.serialNum = null;
      this.macAddr = null;
      this.destIPAddr = null;
      this.dataUdpSrcPort = null;
      this.dataUdpDestPort = null;
      this.diagUdpSrcPort = null;
      this.diagUdpDestPort = null;
      this.hwVer = null;
      this.imgVer = null;
      this.imgHash = null;
      this.devFWUpgradeStatus = null;
      this.storedDataDestIPAddr = null;
      this.storedDataDestPort = null;
      this.storedDataMacAddr = null;
      this.storedDiagDestIPAddr = null;
      this.storedDiagDestPort = null;
      this.storedDiagMacAddr = null;
      this.storedSysDestIPAddr = null;
      this.storedSysMacAddr = null;
      this.systemTemperatureCelsius = null;
      this.systemVoltageVolts = null;
      this.scanPeriod = null;
      this.returnType = null;
      this.frameRateHz = null;
      this.ptpLocked = null;
      this.rtcSeconds = null;
      this.rtcNanoSeconds = null;
      this.offsetNanoSeconds = null;
      this.masterClockID = null;
      this.faults = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
      if (initObj.hasOwnProperty('modelNum')) {
        this.modelNum = initObj.modelNum
      }
      else {
        this.modelNum = '';
      }
      if (initObj.hasOwnProperty('serialNum')) {
        this.serialNum = initObj.serialNum
      }
      else {
        this.serialNum = '';
      }
      if (initObj.hasOwnProperty('macAddr')) {
        this.macAddr = initObj.macAddr
      }
      else {
        this.macAddr = '';
      }
      if (initObj.hasOwnProperty('destIPAddr')) {
        this.destIPAddr = initObj.destIPAddr
      }
      else {
        this.destIPAddr = '';
      }
      if (initObj.hasOwnProperty('dataUdpSrcPort')) {
        this.dataUdpSrcPort = initObj.dataUdpSrcPort
      }
      else {
        this.dataUdpSrcPort = 0;
      }
      if (initObj.hasOwnProperty('dataUdpDestPort')) {
        this.dataUdpDestPort = initObj.dataUdpDestPort
      }
      else {
        this.dataUdpDestPort = 0;
      }
      if (initObj.hasOwnProperty('diagUdpSrcPort')) {
        this.diagUdpSrcPort = initObj.diagUdpSrcPort
      }
      else {
        this.diagUdpSrcPort = 0;
      }
      if (initObj.hasOwnProperty('diagUdpDestPort')) {
        this.diagUdpDestPort = initObj.diagUdpDestPort
      }
      else {
        this.diagUdpDestPort = 0;
      }
      if (initObj.hasOwnProperty('hwVer')) {
        this.hwVer = initObj.hwVer
      }
      else {
        this.hwVer = '';
      }
      if (initObj.hasOwnProperty('imgVer')) {
        this.imgVer = initObj.imgVer
      }
      else {
        this.imgVer = '';
      }
      if (initObj.hasOwnProperty('imgHash')) {
        this.imgHash = initObj.imgHash
      }
      else {
        this.imgHash = '';
      }
      if (initObj.hasOwnProperty('devFWUpgradeStatus')) {
        this.devFWUpgradeStatus = initObj.devFWUpgradeStatus
      }
      else {
        this.devFWUpgradeStatus = '';
      }
      if (initObj.hasOwnProperty('storedDataDestIPAddr')) {
        this.storedDataDestIPAddr = initObj.storedDataDestIPAddr
      }
      else {
        this.storedDataDestIPAddr = '';
      }
      if (initObj.hasOwnProperty('storedDataDestPort')) {
        this.storedDataDestPort = initObj.storedDataDestPort
      }
      else {
        this.storedDataDestPort = 0;
      }
      if (initObj.hasOwnProperty('storedDataMacAddr')) {
        this.storedDataMacAddr = initObj.storedDataMacAddr
      }
      else {
        this.storedDataMacAddr = '';
      }
      if (initObj.hasOwnProperty('storedDiagDestIPAddr')) {
        this.storedDiagDestIPAddr = initObj.storedDiagDestIPAddr
      }
      else {
        this.storedDiagDestIPAddr = '';
      }
      if (initObj.hasOwnProperty('storedDiagDestPort')) {
        this.storedDiagDestPort = initObj.storedDiagDestPort
      }
      else {
        this.storedDiagDestPort = 0;
      }
      if (initObj.hasOwnProperty('storedDiagMacAddr')) {
        this.storedDiagMacAddr = initObj.storedDiagMacAddr
      }
      else {
        this.storedDiagMacAddr = '';
      }
      if (initObj.hasOwnProperty('storedSysDestIPAddr')) {
        this.storedSysDestIPAddr = initObj.storedSysDestIPAddr
      }
      else {
        this.storedSysDestIPAddr = '';
      }
      if (initObj.hasOwnProperty('storedSysMacAddr')) {
        this.storedSysMacAddr = initObj.storedSysMacAddr
      }
      else {
        this.storedSysMacAddr = '';
      }
      if (initObj.hasOwnProperty('systemTemperatureCelsius')) {
        this.systemTemperatureCelsius = initObj.systemTemperatureCelsius
      }
      else {
        this.systemTemperatureCelsius = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('systemVoltageVolts')) {
        this.systemVoltageVolts = initObj.systemVoltageVolts
      }
      else {
        this.systemVoltageVolts = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('scanPeriod')) {
        this.scanPeriod = initObj.scanPeriod
      }
      else {
        this.scanPeriod = 0.0;
      }
      if (initObj.hasOwnProperty('returnType')) {
        this.returnType = initObj.returnType
      }
      else {
        this.returnType = 0;
      }
      if (initObj.hasOwnProperty('frameRateHz')) {
        this.frameRateHz = initObj.frameRateHz
      }
      else {
        this.frameRateHz = 0.0;
      }
      if (initObj.hasOwnProperty('ptpLocked')) {
        this.ptpLocked = initObj.ptpLocked
      }
      else {
        this.ptpLocked = false;
      }
      if (initObj.hasOwnProperty('rtcSeconds')) {
        this.rtcSeconds = initObj.rtcSeconds
      }
      else {
        this.rtcSeconds = 0;
      }
      if (initObj.hasOwnProperty('rtcNanoSeconds')) {
        this.rtcNanoSeconds = initObj.rtcNanoSeconds
      }
      else {
        this.rtcNanoSeconds = 0;
      }
      if (initObj.hasOwnProperty('offsetNanoSeconds')) {
        this.offsetNanoSeconds = initObj.offsetNanoSeconds
      }
      else {
        this.offsetNanoSeconds = 0;
      }
      if (initObj.hasOwnProperty('masterClockID')) {
        this.masterClockID = initObj.masterClockID
      }
      else {
        this.masterClockID = '';
      }
      if (initObj.hasOwnProperty('faults')) {
        this.faults = initObj.faults
      }
      else {
        this.faults = new Array(6).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Diagnostic
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = _serializer.uint8(obj.state, buffer, bufferOffset);
    // Serialize message field [modelNum]
    bufferOffset = _serializer.string(obj.modelNum, buffer, bufferOffset);
    // Serialize message field [serialNum]
    bufferOffset = _serializer.string(obj.serialNum, buffer, bufferOffset);
    // Serialize message field [macAddr]
    bufferOffset = _serializer.string(obj.macAddr, buffer, bufferOffset);
    // Serialize message field [destIPAddr]
    bufferOffset = _serializer.string(obj.destIPAddr, buffer, bufferOffset);
    // Serialize message field [dataUdpSrcPort]
    bufferOffset = _serializer.uint16(obj.dataUdpSrcPort, buffer, bufferOffset);
    // Serialize message field [dataUdpDestPort]
    bufferOffset = _serializer.uint16(obj.dataUdpDestPort, buffer, bufferOffset);
    // Serialize message field [diagUdpSrcPort]
    bufferOffset = _serializer.uint16(obj.diagUdpSrcPort, buffer, bufferOffset);
    // Serialize message field [diagUdpDestPort]
    bufferOffset = _serializer.uint16(obj.diagUdpDestPort, buffer, bufferOffset);
    // Serialize message field [hwVer]
    bufferOffset = _serializer.string(obj.hwVer, buffer, bufferOffset);
    // Serialize message field [imgVer]
    bufferOffset = _serializer.string(obj.imgVer, buffer, bufferOffset);
    // Serialize message field [imgHash]
    bufferOffset = _serializer.string(obj.imgHash, buffer, bufferOffset);
    // Serialize message field [devFWUpgradeStatus]
    bufferOffset = _serializer.string(obj.devFWUpgradeStatus, buffer, bufferOffset);
    // Serialize message field [storedDataDestIPAddr]
    bufferOffset = _serializer.string(obj.storedDataDestIPAddr, buffer, bufferOffset);
    // Serialize message field [storedDataDestPort]
    bufferOffset = _serializer.uint16(obj.storedDataDestPort, buffer, bufferOffset);
    // Serialize message field [storedDataMacAddr]
    bufferOffset = _serializer.string(obj.storedDataMacAddr, buffer, bufferOffset);
    // Serialize message field [storedDiagDestIPAddr]
    bufferOffset = _serializer.string(obj.storedDiagDestIPAddr, buffer, bufferOffset);
    // Serialize message field [storedDiagDestPort]
    bufferOffset = _serializer.uint16(obj.storedDiagDestPort, buffer, bufferOffset);
    // Serialize message field [storedDiagMacAddr]
    bufferOffset = _serializer.string(obj.storedDiagMacAddr, buffer, bufferOffset);
    // Serialize message field [storedSysDestIPAddr]
    bufferOffset = _serializer.string(obj.storedSysDestIPAddr, buffer, bufferOffset);
    // Serialize message field [storedSysMacAddr]
    bufferOffset = _serializer.string(obj.storedSysMacAddr, buffer, bufferOffset);
    // Check that the constant length array field [systemTemperatureCelsius] has the right length
    if (obj.systemTemperatureCelsius.length !== 4) {
      throw new Error('Unable to serialize array field systemTemperatureCelsius - length must be 4')
    }
    // Serialize message field [systemTemperatureCelsius]
    bufferOffset = _arraySerializer.float32(obj.systemTemperatureCelsius, buffer, bufferOffset, 4);
    // Check that the constant length array field [systemVoltageVolts] has the right length
    if (obj.systemVoltageVolts.length !== 6) {
      throw new Error('Unable to serialize array field systemVoltageVolts - length must be 6')
    }
    // Serialize message field [systemVoltageVolts]
    bufferOffset = _arraySerializer.float32(obj.systemVoltageVolts, buffer, bufferOffset, 6);
    // Serialize message field [scanPeriod]
    bufferOffset = _serializer.float32(obj.scanPeriod, buffer, bufferOffset);
    // Serialize message field [returnType]
    bufferOffset = _serializer.uint8(obj.returnType, buffer, bufferOffset);
    // Serialize message field [frameRateHz]
    bufferOffset = _serializer.float32(obj.frameRateHz, buffer, bufferOffset);
    // Serialize message field [ptpLocked]
    bufferOffset = _serializer.bool(obj.ptpLocked, buffer, bufferOffset);
    // Serialize message field [rtcSeconds]
    bufferOffset = _serializer.uint32(obj.rtcSeconds, buffer, bufferOffset);
    // Serialize message field [rtcNanoSeconds]
    bufferOffset = _serializer.uint32(obj.rtcNanoSeconds, buffer, bufferOffset);
    // Serialize message field [offsetNanoSeconds]
    bufferOffset = _serializer.uint32(obj.offsetNanoSeconds, buffer, bufferOffset);
    // Serialize message field [masterClockID]
    bufferOffset = _serializer.string(obj.masterClockID, buffer, bufferOffset);
    // Check that the constant length array field [faults] has the right length
    if (obj.faults.length !== 6) {
      throw new Error('Unable to serialize array field faults - length must be 6')
    }
    // Serialize message field [faults]
    bufferOffset = _arraySerializer.bool(obj.faults, buffer, bufferOffset, 6);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Diagnostic
    let len;
    let data = new Diagnostic(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [modelNum]
    data.modelNum = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [serialNum]
    data.serialNum = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [macAddr]
    data.macAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [destIPAddr]
    data.destIPAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [dataUdpSrcPort]
    data.dataUdpSrcPort = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [dataUdpDestPort]
    data.dataUdpDestPort = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [diagUdpSrcPort]
    data.diagUdpSrcPort = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [diagUdpDestPort]
    data.diagUdpDestPort = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [hwVer]
    data.hwVer = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [imgVer]
    data.imgVer = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [imgHash]
    data.imgHash = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [devFWUpgradeStatus]
    data.devFWUpgradeStatus = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [storedDataDestIPAddr]
    data.storedDataDestIPAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [storedDataDestPort]
    data.storedDataDestPort = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [storedDataMacAddr]
    data.storedDataMacAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [storedDiagDestIPAddr]
    data.storedDiagDestIPAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [storedDiagDestPort]
    data.storedDiagDestPort = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [storedDiagMacAddr]
    data.storedDiagMacAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [storedSysDestIPAddr]
    data.storedSysDestIPAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [storedSysMacAddr]
    data.storedSysMacAddr = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [systemTemperatureCelsius]
    data.systemTemperatureCelsius = _arrayDeserializer.float32(buffer, bufferOffset, 4)
    // Deserialize message field [systemVoltageVolts]
    data.systemVoltageVolts = _arrayDeserializer.float32(buffer, bufferOffset, 6)
    // Deserialize message field [scanPeriod]
    data.scanPeriod = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [returnType]
    data.returnType = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [frameRateHz]
    data.frameRateHz = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ptpLocked]
    data.ptpLocked = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [rtcSeconds]
    data.rtcSeconds = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [rtcNanoSeconds]
    data.rtcNanoSeconds = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [offsetNanoSeconds]
    data.offsetNanoSeconds = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [masterClockID]
    data.masterClockID = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [faults]
    data.faults = _arrayDeserializer.bool(buffer, bufferOffset, 6)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.modelNum);
    length += _getByteLength(object.serialNum);
    length += _getByteLength(object.macAddr);
    length += _getByteLength(object.destIPAddr);
    length += _getByteLength(object.hwVer);
    length += _getByteLength(object.imgVer);
    length += _getByteLength(object.imgHash);
    length += _getByteLength(object.devFWUpgradeStatus);
    length += _getByteLength(object.storedDataDestIPAddr);
    length += _getByteLength(object.storedDataMacAddr);
    length += _getByteLength(object.storedDiagDestIPAddr);
    length += _getByteLength(object.storedDiagMacAddr);
    length += _getByteLength(object.storedSysDestIPAddr);
    length += _getByteLength(object.storedSysMacAddr);
    length += _getByteLength(object.masterClockID);
    return length + 141;
  }

  static datatype() {
    // Returns string type for a message object
    return 'lidar_msgs_r1/Diagnostic';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '63993f1ecb7807d8126ec5ed4e4b3e2c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2019-2022 Velodyne Lidar.
    # VELODYNE LIDAR CONFIDENTIAL & PROPRIETARY INFORMATION
    
    # Velarray diagnostic packet
    Header header       # standard ROS message header
    
    uint8 state			# system state
    
    # system states
    uint8 INITIALIZING=0		
    uint8 OPERATIONAL=1
    
    string modelNum		# system model number hex string
    string serialNum		# system serial number hex string
    string macAddr			# system MAC address in xx:xx:xx:xx:xx:xx format
    string destIPAddr		# data stream destination IP address xxx.xxx.xxx.xxx
    uint16 dataUdpSrcPort	# data stream UDP source port
    uint16 dataUdpDestPort	# data stream UDP destination port
    uint16 diagUdpSrcPort	# diagnostic stream UDP source port
    uint16 diagUdpDestPort	# diagnostic stream UDP destination port
    
    string hwVer			# system hardware version hex string
    string imgVer			# system image version x.x.x.x
    string imgHash			# system image hash hex string
    string devFWUpgradeStatus	# device firmware upgrade status
    
    string storedDataDestIPAddr	# stored data stream destination IP address xxx.xxx.xxx.xxx
    uint16 storedDataDestPort	# stored data stream UDP destination port
    string storedDataMacAddr	# stored data stream destination MAC address in xx:xx:xx:xx:xx:xx format
    string storedDiagDestIPAddr	# stored diagnostic stream destination IP address xxx.xxx.xxx.xxx
    uint16 storedDiagDestPort	# stored diagnostic stream UDP destination port
    string storedDiagMacAddr	# stored diagnostic stream destination MAC address in xx:xx:xx:xx:xx:xx format
    string storedSysDestIPAddr	# stored system source IP address xxx.xxx.xxx.xxx
    string storedSysMacAddr		# stored system source MAC address in xx:xx:xx:xx:xx:xx format
    
    float32[4] systemTemperatureCelsius	# system temperatures
    float32[6] systemVoltageVolts		# system HV, 21V, 12V, 3.3, HV2, and HV3 voltages
    float32 scanPeriod	# scan period
    uint8 returnType	# laser return type
    
    # laser return types
    uint8 FIRST = 1
    uint8 STRONGEST = 2
    uint8 FIRST_STRONGEST = 3
    uint8 LAST = 8
    uint8 STRONGEST_LAST = 10
    
    float32 frameRateHz	# frame rate: 25hz, 12.5hz, 20hz, and 10hz
    
    bool ptpLocked              # PTP Lock
    uint32 rtcSeconds           # real time clock in seconds
    uint32 rtcNanoSeconds       # real time clock in nanoseconds
    uint32 offsetNanoSeconds    # offset from master clock in nanoseconds
    string masterClockID        # master clock ID
    
    bool[6] faults		# emission, scan, power regulation, thermal fault,
    					# thermal warning, and manufacturing info fault
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Diagnostic(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    if (msg.modelNum !== undefined) {
      resolved.modelNum = msg.modelNum;
    }
    else {
      resolved.modelNum = ''
    }

    if (msg.serialNum !== undefined) {
      resolved.serialNum = msg.serialNum;
    }
    else {
      resolved.serialNum = ''
    }

    if (msg.macAddr !== undefined) {
      resolved.macAddr = msg.macAddr;
    }
    else {
      resolved.macAddr = ''
    }

    if (msg.destIPAddr !== undefined) {
      resolved.destIPAddr = msg.destIPAddr;
    }
    else {
      resolved.destIPAddr = ''
    }

    if (msg.dataUdpSrcPort !== undefined) {
      resolved.dataUdpSrcPort = msg.dataUdpSrcPort;
    }
    else {
      resolved.dataUdpSrcPort = 0
    }

    if (msg.dataUdpDestPort !== undefined) {
      resolved.dataUdpDestPort = msg.dataUdpDestPort;
    }
    else {
      resolved.dataUdpDestPort = 0
    }

    if (msg.diagUdpSrcPort !== undefined) {
      resolved.diagUdpSrcPort = msg.diagUdpSrcPort;
    }
    else {
      resolved.diagUdpSrcPort = 0
    }

    if (msg.diagUdpDestPort !== undefined) {
      resolved.diagUdpDestPort = msg.diagUdpDestPort;
    }
    else {
      resolved.diagUdpDestPort = 0
    }

    if (msg.hwVer !== undefined) {
      resolved.hwVer = msg.hwVer;
    }
    else {
      resolved.hwVer = ''
    }

    if (msg.imgVer !== undefined) {
      resolved.imgVer = msg.imgVer;
    }
    else {
      resolved.imgVer = ''
    }

    if (msg.imgHash !== undefined) {
      resolved.imgHash = msg.imgHash;
    }
    else {
      resolved.imgHash = ''
    }

    if (msg.devFWUpgradeStatus !== undefined) {
      resolved.devFWUpgradeStatus = msg.devFWUpgradeStatus;
    }
    else {
      resolved.devFWUpgradeStatus = ''
    }

    if (msg.storedDataDestIPAddr !== undefined) {
      resolved.storedDataDestIPAddr = msg.storedDataDestIPAddr;
    }
    else {
      resolved.storedDataDestIPAddr = ''
    }

    if (msg.storedDataDestPort !== undefined) {
      resolved.storedDataDestPort = msg.storedDataDestPort;
    }
    else {
      resolved.storedDataDestPort = 0
    }

    if (msg.storedDataMacAddr !== undefined) {
      resolved.storedDataMacAddr = msg.storedDataMacAddr;
    }
    else {
      resolved.storedDataMacAddr = ''
    }

    if (msg.storedDiagDestIPAddr !== undefined) {
      resolved.storedDiagDestIPAddr = msg.storedDiagDestIPAddr;
    }
    else {
      resolved.storedDiagDestIPAddr = ''
    }

    if (msg.storedDiagDestPort !== undefined) {
      resolved.storedDiagDestPort = msg.storedDiagDestPort;
    }
    else {
      resolved.storedDiagDestPort = 0
    }

    if (msg.storedDiagMacAddr !== undefined) {
      resolved.storedDiagMacAddr = msg.storedDiagMacAddr;
    }
    else {
      resolved.storedDiagMacAddr = ''
    }

    if (msg.storedSysDestIPAddr !== undefined) {
      resolved.storedSysDestIPAddr = msg.storedSysDestIPAddr;
    }
    else {
      resolved.storedSysDestIPAddr = ''
    }

    if (msg.storedSysMacAddr !== undefined) {
      resolved.storedSysMacAddr = msg.storedSysMacAddr;
    }
    else {
      resolved.storedSysMacAddr = ''
    }

    if (msg.systemTemperatureCelsius !== undefined) {
      resolved.systemTemperatureCelsius = msg.systemTemperatureCelsius;
    }
    else {
      resolved.systemTemperatureCelsius = new Array(4).fill(0)
    }

    if (msg.systemVoltageVolts !== undefined) {
      resolved.systemVoltageVolts = msg.systemVoltageVolts;
    }
    else {
      resolved.systemVoltageVolts = new Array(6).fill(0)
    }

    if (msg.scanPeriod !== undefined) {
      resolved.scanPeriod = msg.scanPeriod;
    }
    else {
      resolved.scanPeriod = 0.0
    }

    if (msg.returnType !== undefined) {
      resolved.returnType = msg.returnType;
    }
    else {
      resolved.returnType = 0
    }

    if (msg.frameRateHz !== undefined) {
      resolved.frameRateHz = msg.frameRateHz;
    }
    else {
      resolved.frameRateHz = 0.0
    }

    if (msg.ptpLocked !== undefined) {
      resolved.ptpLocked = msg.ptpLocked;
    }
    else {
      resolved.ptpLocked = false
    }

    if (msg.rtcSeconds !== undefined) {
      resolved.rtcSeconds = msg.rtcSeconds;
    }
    else {
      resolved.rtcSeconds = 0
    }

    if (msg.rtcNanoSeconds !== undefined) {
      resolved.rtcNanoSeconds = msg.rtcNanoSeconds;
    }
    else {
      resolved.rtcNanoSeconds = 0
    }

    if (msg.offsetNanoSeconds !== undefined) {
      resolved.offsetNanoSeconds = msg.offsetNanoSeconds;
    }
    else {
      resolved.offsetNanoSeconds = 0
    }

    if (msg.masterClockID !== undefined) {
      resolved.masterClockID = msg.masterClockID;
    }
    else {
      resolved.masterClockID = ''
    }

    if (msg.faults !== undefined) {
      resolved.faults = msg.faults;
    }
    else {
      resolved.faults = new Array(6).fill(0)
    }

    return resolved;
    }
};

// Constants for message
Diagnostic.Constants = {
  INITIALIZING: 0,
  OPERATIONAL: 1,
  FIRST: 1,
  STRONGEST: 2,
  FIRST_STRONGEST: 3,
  LAST: 8,
  STRONGEST_LAST: 10,
}

module.exports = Diagnostic;
