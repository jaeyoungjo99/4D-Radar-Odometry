# Velodyne Lidar Driver {#mainpage}

## Table of Contents

1. [Package Overview](#package-overview)
2. [Getting Started](#getting-started)
3. [Tools](#tools)
4. [Driver Configuration](#driver-configuration)
5. [ROS Usage](#ros)
6. [Troubleshooting](#troubleshooting)
7. [Copyright Notice](#copyright-notice)

## Package Overview {#package-overview}

The Velodyne Lidar Driver and ROS node are packaged in `.deb` format.

The Debian (.deb) distribution consists of two separate packages for Ubuntu 18 and ROS Melodic, or Ubuntu 20 and ROS Noetic:

* velodyne-lidar-driver (contains the shared library and tools)
* ros-melodic-velodyne-lidar-driver, or ros-noetic-velodyne-lidar-driver (contains a compiled ROS node executable)

## Getting Started {#getting-started}

Before developing with the Velodyne lidar driver, make sure your Velodyne lidar device is plugged in and has been configured. Consult the device's manual for instructions.

### Dependencies

This package has been tested with the following dependencies:

* Ubuntu 18.04 or 20.04
* libgoogle-glog0v5
* libconfig++9v5
* libpcap0.8
* libboost-program-options
* libboost-serialization
* libboost-filesystem

Boost 1.65 and 1.71 have been tested on Ubuntu 18.04 and Ubuntu 20.04, respectively.

On Ubuntu 18.04, these can be installed by running

    apt-get install -y libgoogle-glog0v5 libconfig++9v5 libpcap0.8 libboost-program-options1.65.1 libboost-serialization1.65.1 libboost-filesystem1.65.1

On Ubuntu 20.04 install the same dependencies but use 1.71.0 for the Boost version.

### Installing the velodyne lidar driver and tools (using apt.)

The Velodyne lidar driver can be installed from a `.deb` file using `apt`. This distribution contains both amd64 and arm64 `.deb` files. To install from one of the provided Debian packages, run

    sudo apt install [.deb]

Or

    sudo dpkg -i [.deb]

where `[.deb]` refers to the Debian file appropriate for your system's architecture.

## Tools {#tools}

The following tools are included in the `velodyne-lidar-driver` package:

* `velodyne_pcap_replay` - used to play back PCAP files containing LiDAR data captured from a Velodyne sensor using Wireshark or `tcpdump`.
* `velodyne_diagnostic` - output the diagnostic stream of a Velodyne sensor, (for Velarray H800 and M1600 only; support for other sensors will appear in a future release.)
* `velodyne_configuration` - modify the configuration of a Velodyne sensor, (for Velarray H800 and M1600 only; support for other sensors will appear in a future release.)

The default install directory for each of these tools is `/opt/velodyne/velodyne-lidar-driver/bin/`. The usage of each tool can be displayed using the `--help` option.

For example,

    velodyne_configuration --help

## Driver Configuration {#driver-configuration}

### Example configuration files

The Velodyne lidar driver must be configured using a `.cfg` file. Locate the default `.cfg` file for the Velodyne hardware.

If the driver was installed from `.deb`, these files can be found in `/opt/velodyne/config`.

Otherwise, they can be found in the `src` directory. For example, `src/arm64/velodyne/config/`.

The default configuration for the Velarray H800 is `lidar_driver_velarray_h800.cfg`.

### Explanation of configuration file parameters

The `.cfg` files used to configure the operation of the lidar driver are hierarchical in nature, using a syntax similar to (but distinct from) YAML or JSON, implemented using `libconfig`. `libconfig`'s syntax is described in greater detail in the [library's documentation](https://hyperrealm.github.io/libconfig/libconfig_manual.html).

At the top level of the file, there are three configuration parameters:

* `ros-node-name` specifies the name of the velodyne-lidar-driver ROS node, if ROS is being used. Although required, the value is not used by the standalone C++ library. This parameter is deprecated because a future version of the Velodyne ROS driver will obtain it from the node's ROS launch file.
* `tai-offset-sec` specifies the offset between International Atomic Time (TAI) and Coordinated Universal Time (UTC).
* `hubs` specifies a list of hubs. A hub represents a "listener" on a specific UDP port. At this time, a hub may listen to multiple sensors so long as they are distinct types. If multiple sensors of the same type are in use, each should be configured to use a different port and each should have its own hub in the `.cfg` file.

A hub contains the following parameters:

* `hub-name` specifies the name of the hub. This value is required.
* `use-hub-namespace`, if true, specifies that the hub name should be prepended to the sensor's ROS topic names (if ROS is in use.) For example, if the hub name is `hub0` and the sensor's `pcl-topic` value is `vlp32_pcl` then the sensor's pcl ROS topic will have the name `/hub0/vlp32_pcl`. Otherwise, if `use-hub-namespace` is false, then the pcl ROS topic will have the name `/vlp32_pcl`.
* `sensors` specifies a list of sensors.

A sensor contains the following parameters:

* `type` specifies the type of the sensor. Currently supported types are VLP-16, VLP-32C, VLS-128, VELARRAY-H800, VELARRAY-M1600. At most, one of each type of sensor is allowed per hub.
* `calibration-file` specifies the calibration file (expected to be located in the same directory as the `.cfg` file) to use for the sensor.
* `packet-topic` specifies the name of the sensor's raw packet ROS topic (if ROS is in use.)
* `pcl-topic` specifies the name of the sensor's PointCloud2 (PCL) topic (if ROS is in use.)
* `pcl-frame-id` provides the value of `frame_id` in the header of PointCloud2 messages (if ROS is in use.) It is used to indicate the coordinate system the data from this sensor is in.
* `use-host-timestamp`, if true, uses host time (as opposed to PTP or GPS time) for each point in the published PointCloud2 (PCL) messages. If false, PTP will be used if available (only for PTP-capable sensors).
* `has-gps` is for rotational sensors (VLP-16, VLP-32C, and VLS-128) only. If true, the driver will assume the sensor has been synchronized with GPS time using an external source and use the device's time for points in PointCloud2 (PCL) messages. This requires that the host's clock be synchronized to within 60 seconds of the GPS clock (when converted to UTC). If the clock difference is too great, data is timestamped according to when the driver receives it.
* `rotate-180deg-x-axis`, if true, specifies that the point clouds should be rotated 180 degrees around the X-axis. (See the sensor manual for information about the sensor's axes.)
* `hor-fov-start-deg` and `hor-fov-end-deg` specify the FOV for a rotational sensor. Only points from blocks having azimuth values between these values will be included in PCL messages. If `hor-fov-end-deg` is zero, or equal to `hor-fov-start-deg`, then the sensor's entire 360 degree FOV is used.

## ROS Usage {#ros}

If developing a ROS application, and if the ROS node package `ros-melodic-velodyne-lidar-driver` is installed, the package's executables and other environment information must be added to the user's environment in order to use them. This can be accomplished by loading the package's setup file, like so

    source /opt/velodyne/velodyne-lidar-driver-ros/setup.bash

Once this is done, the node can be launched using `rosrun`. For example,

    rosrun velodyne_ros1_lidar_driver velodyne_ros1_lidar_driver _config_file:=[path to config file]

### Launch files

One can also launch the node using `roslaunch` by providing a launch file. Below is a minimal launch file example that launches a single instance of the `velodyne_ros1_lidar_driver` node, specifying a configuration file for the lidar driver.

    <launch>
        <node name="velodyne_ros1_lidar_driver" pkg="velodyne_ros1_lidar_driver" type="velodyne_ros1_lidar_driver">
            <param name="config_file" value="configfile.cfg" />
        </node>
    </launch>

In the above example, the value for the `config_file` param should be replaced by the path to a configuration file. Alternatively, the value can be provided using a substitution argument. Please consult the [roslaunch/XML documentation](http://wiki.ros.org/roslaunch/XML) for more information.

Once a launch file is created, the launch file can be included in a parent launch file (if the node is being used as part of a larger, multi-node ROS application) or launched directly, e.g. by running

    roslaunch [path to launchfile]

### Logging the ROS node's output

This version of the Velodyne ROS node uses [Google's glog](https://github.com/google/glog) for logging as opposed to [ROS's logging framework](http://wiki.ros.org/roscpp/Overview/Logging). Support for ROS logging will be added in a future release. In the meantime, please refer to the glog documentation for notes on configuring logging. Note, for debugging purposes it is often sufficient to specify an environment variable `GLOG_logtostderr=1` when launching the ROS node to have the node's logs sent to `stderr`:

    GLOG_logtostderr=1 rosrun velodyne_ros1_lidar_driver velodyne_ros1_lidar_driver _config_file:=[path to config file]

## Troubleshooting {#troubleshooting}

If a callback is registered with a sensor but the callback is never invoked, make sure the device's network configuration is correct and that data is being received. One way to do this is to use `tcpdump` to view UDP packets coming from the device. The following command can display data packets being sent on port 2368. (Note, in this example, the Velodyne lidar device is connected to the `eth0` interface. This may vary from system to system; make sure to specify the interface that is attached to the Velodyne device.)

    sudo tcpdump -i eth0 udp port 2368 -vv -X

If the output of this command contains packet information, that means the system is receiving packets from the device.

    15:11:27.370068 IP (tos 0x0, ttl 255, id 0, offset 0, flags [DF], proto UDP (17), length 1332)
    192.168.100.202.2368 > localhost.2368: [no cksum] UDP, length 1304
        0x0000:  4500 0534 0000 4000 ff11 2c84 c0a8 64ca  E..4..@...,...d.
        0x0010:  c0a8 6419 0940 0940 0520 0000 1500 1140  ..d..@.@.......@
        0x0020:  027a e819 0000 420e 3b36 8230 1002 0001  .z....B.;6.0....
        0x0030:  8078 2c35 0b28 0507 8078 2c32 0d84 1803  .x,5.(...x,2....
    ...

## Copyright Notice {#copyright-notice}

*Copyright 2019-2022 Velodyne Lidar.*
*VELODYNE LIDAR CONFIDENTIAL & PROPRIETARY INFORMATION*
*DO NOT REDISTRIBUTE*
